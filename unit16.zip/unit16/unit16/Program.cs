﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace unit16
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter 1 for black BG:");
            Console.WriteLine("enter 2 for white BG:");
            Console.WriteLine("enter 2 for green BG:");
            int num = Convert.ToInt32(Console.ReadLine());
            switch (num)
            {
                case 1:
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Clear();
                    break;

                case 2:
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.Clear();
                    break;

                case 3:
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;

               
                default:

                    Console.Write("enter num  between 1 to 3");
                    break;

            }
            Console.Read();
        }
    }
}
