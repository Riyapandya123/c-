﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace unit18
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] arr = new int[4][];
        {
            arr[0] = new int[]{11, 21, 56, 78};
            arr[1] = new int[]{2, 5, 6};
            arr[2] = new int[]{2, 5,10,2,15};
            arr[3]=  new int[]{2,5,10,15,20,15};
        }

        // Traverse array elements  
        for (int i = 0; i < arr.Length; i++) {
            for (int j = 0; j < arr[i].Length; j++) {
                Console.Write(arr[i][j] + " ");
            }
            Console.Read();
        }
      }
   }
}
